# SENG1050

Assignemnt Part 1 to be found here.

Please use Chromium or Google Chrome to view. I have not tested under Firefox, Opera, InternetExplorer, Edge, Vivaldi etc etc.

There is no reason for me to assume they won't work, however I know the results of using Chromium allow the expected layout.

Thanks,
Jay Rovacsek - c3146220

Files included:

	AssignemntItemCoverSheet.pdf
	
	README.txt
	
    index.html
    indian.xml
    japanese.xml
    style.css
    template.xml

    images/indian.jpg
    images/japanese.jpg
    images/italian.jpg
    images/uruguayan.jpg
    images/ethiopian.jpg
    images/restaurant-CC.jpg

    errors/underConstructionError.txt